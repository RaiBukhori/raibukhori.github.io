# Selir Apokalips — versi modular (v35)

## Menjalankan
- **Laptop:** dobel-klik `index.html`. Tidak perlu server (dicoba di Chromium).
- **`index.html` saja:** boleh dibuka sendirian, tanpa folder `games/`, `selir/`, dan `setting/`. Markas jalan penuh. Tab **Action** tetap menampilkan tombol game, dan tiap game terbuka sebagai halaman kosong ("Belum dimuat"). Tab **Selir** terbuka dengan daftar kosong. Tab **Pengaturan** hanya menampilkan keterangan "Belum dimuat". Begitu folder `games/`, `selir/`, dan `setting/` ditaruh di sampingnya, semuanya terisi otomatis tanpa mengubah apa pun. Selama selir belum termuat, daftar selir kosong tidak ikut disimpan, jadi save tidak rusak.
- **HP:** browser HP umumnya tidak bisa membaca file di subfolder, jadi paket modular ini dipakai di laptop.

## Struktur
```
index.html            kerangka + Markas + poster bawaan (girl/pt) + animasi kartu selir (intro) + penyambung modul (loader)
games/manifest.html   daftar game di menu Action (menu dibuat otomatis dari sini)
games/<id>/<id>.html  satu game: base_defend (Base Defend), war, misi, scavenge (dimuat saat menunya dibuka)
games/_template/      contoh game baru
selir/manifest.html   daftar selir (urutan = urutan tampil) + selir awal save baru
selir/layout.html     tampilan tab Selir: kartu poster 9:16 + bintang level (opsional; tanpa file ini tab Selir pakai daftar biasa)
selir/<nama>/         poster.html, base_defend.html, war.html, misi.html, scavenge.html
selir/_template/      contoh selir baru
setting/manifest.html daftar menu tab Pengaturan (urutan = urutan tombol)
setting/layout.html   tampilan tab Pengaturan: profil + tombol menu + kotak konfirmasi + CSS-nya (dimuat saat tab dibuka)
setting/<id>/<id>.html  satu menu: reset, edit, import, save (dimuat saat tombolnya ditekan)
setting/_template/    contoh menu baru
```
Folder `core/` sudah tidak ada: isi `core/shared.html` (poster bawaan + intro) kini menyatu di `index.html`.

## Tambah selir
1. Salin `selir/_template` menjadi `selir/<nama>`.
2. Edit `poster.html` (id baru, nama, kelas, warna, `img` atau fungsi `poster(s)`), lalu file per game. Semua selir setara: tidak ada rarity.
3. Tambahkan `"<nama>"` ke `selir/manifest.html`.

Selir yang hanya punya `poster.html` tetap bisa main di semua game dengan perilaku default.
Jangan ubah `id` selir setelah ada save, dan jangan ubah key save `selir_apo1`.

## Tambah game
1. Salin `games/_template/_template.html` menjadi `games/<id>/<id>.html`, ganti `contoh` dengan `<id>`.
2. Tambahkan satu baris di `games/manifest.html`.
3. Opsional: perk selir di `selir/<nama>/<id>.html` + tambahkan `"<id>"` ke `games:[...]` di `poster.html`.

Daftar game bawaan di loader `index.html` (`DG`) hanya cadangan untuk mode `index.html` saja. Kalau `games/manifest.html` ada, dialah yang dipakai, jadi menambah game cukup lewat manifest.

## Base Defend memakai gambar & animasi Markas
Base Defend (`games/base_defend/base_defend.html`) **tidak punya gambar tank/rider/blokade sendiri**. Semua dipanggil dari `index.html`:
| Gambar | Fungsi Markas | Dipakai di Markas oleh |
|---|---|---|
| Tank (laras ke bawah, `rc` = recoil, `ph` = rantai berjalan) | `tankArt(g,x,y,rc,ph)` | `tkImg()` |
| Rider Harley (shotgun / SCAR) | `bikeArt(g,x,s,b)` | `tkImg()` |
| Daun pintu blokade | `gateDoorArt(g)` | `gtImg()` |
| Tembok + kontainer, menara, ladang zombie, Mansion, pabrik | `cWall(gate)`, `towerImg()`, `cField()`, `mansion()`, `facBld()` … | `mapArt()` |
Mengubah tampilan tank/rider/pintu di Markas otomatis ikut berubah di Base Defend. `cWall(0)` = tembok tanpa daun pintu (supaya daun bisa digeser membuka).

Alur: **intro** = kamera persis layar Markas (menghadap sisi zombie) → pintu blokade membuka (percikan baja, debu, sorot lampu) → tank tengah langsung menembakkan artileri dari tempatnya → tank & rider keluar lewat pintu dengan sorot lampu, jejak rantai/ban permanen, asap knalpot, drift percik api, menggilas zombie, dan menembak aktif (peluru artileri + ledakan kawah, shotgun & SCAR) → Bos + selir keluar dari Mansion ke pintu → kamera berputar 180° dan pindah ke Bos → **tarung**: formasi lurus dari depan: Bos → selir → tank → rider (semuanya tetap ada di dunia, hanya di luar kamera sehingga tidak digambar); Bos hampir menempel dasar layar, zombie datang dari atas dan berhenti di depan Bos (`STOP`). Jadwal intro ada di `mkU()` (kolom `d` = detik mulai); `T0` = detik tank tengah menembak; `DOOR` = waktu pintu membuka.

## Hook per selir
| Game | Isi `APO.selirGame(id, game, {...})` |
|---|---|
| base_defend (Base Defend) | `stats:{k,p,c}` (jenis skill, kekuatan, cooldown; cooldown di game = `c` × `CDK`=3 detik) · opsional `cast({c,s,a,p,x,y,hit})` (`x,y` = posisi Bos; `hit(z,dmg,x,y,tampilkanAngka)`) |
| war | `skill:[nama,deskripsi]` · `apply(W)` (n, sh, dm, fr, zs, bl, spread, gap) |
| scavenge | `skill:[nama,deskripsi]` · `ai:{iv,d,c,...}` · `apply(P)` |
| misi | belum dipakai (kosong) |

## Tampilan Selir (`selir/layout.html`)
Tab **Selir** menampilkan kartu poster 9:16 (4 per baris, tanpa nama) dengan baris bintang di bawahnya. Ketuk kartu untuk membuka lembar detail (nama, kelas, serangan, skill) berisi tombol **Kamar**. Siluet = belum bergabung. Tidak ada mekanisme Pasukan: semua selir yang sudah bergabung ikut di Base Defend (War dan Scavenge punya pilihan ikut sendiri).

Bintang = level skill selir (`S.own[id].sl`, yang tampil sebagai "Lv" di Kamar):

| Level | Bintang |
|---|---|
| 1–5 | kayu (cokelat gelap), 1–5 bintang (level 1 = 1 bintang di tengah) |
| 6–10 | silver, 1–5 bintang |
| 11–15 | emas, 1–5 bintang |
| 16–20 | berlian, 1–5 bintang |
| 21–25 | gradasi ungu → biru → pink, 1–5 bintang |
| 26+ | 1 bintang bersayap (badan gradasi ungu-biru, sayap pink polos) |

- Batas level skill di game saat ini `2 + 2 × kedekatan` = 12 (lihat `upS` di `index.html`), jadi di permainan baru tampil kayu, silver, dan emas. Tier berikutnya muncul otomatis begitu batas itu dinaikkan.
- Buka `selir/layout.html` langsung di browser (dobel-klik) untuk pratinjau semua level 1–26.
- Poster: kalau `img` diisi, gambar tampil 9:16 utuh; poster vektor bawaan (2:3) dipotong tipis di kiri-kanan.
- Semua bintang berbentuk ✦ dan digambar di `<canvas>` (bukan SVG), satu kanvas per baris bintang, resolusi 80% dari piksel layar (`RES` di `selir/layout.html`). Kode desain ada di file ini saja, bukan di `index.html`; `index.html` hanya memanggil `APO.layout.sel(...)`.
- Bintang dibuat besar dan hampir menempel. Ukuran, celah antar-bintang, dan margin atas/bawah diatur lewat konstanta `SS`, `GP`, `PD` di dekat fungsi `star` pada `selir/layout.html`. Radius sudut kartu 8px supaya bintang terluar tidak terpotong lengkung sudut di HP sempit (kalau bintang diperbesar lagi, radius ikut diperkecil).

## Pengaturan (tab paling kanan di nav bawah)
Konsepnya sama dengan Action dan Selir: `index.html` hanya menyimpan kerangka kecil (`vSet` + `APO.setUp`), sedangkan menu, tampilan, dan semua fungsinya ada di folder `setting/`.
- **Kapan dimuat:** `setting/manifest.html` + `setting/layout.html` dimuat **sekali saat tab Pengaturan pertama kali dibuka** (ada tulisan "Memuat pengaturan…" sekejap). File tiap menu (`setting/<id>/<id>.html`) dimuat **saat tombolnya pertama kali ditekan**. Selama tab ini belum dibuka, tidak ada satu byte pun dari `setting/` yang dimuat. Di tab lain tidak ada kerja sama sekali (resize/tema hanya memicu gambar ulang kalau tab ini yang aktif).
- **`setting/layout.html`**: profil, deretan tombol (dibuat dari manifest), kotak konfirmasi `ask(...)`, dan pembantu bersama yang dipakai menu lewat `APO.setting` (`ask`, `set`, `refresh`, `draw`, `esc`, `oids`, `pwr`, `num`, `lim`). Semua CSS Pengaturan (`.cf*`) juga di sini, bukan di `index.html`.
- **Profil**: satu `<canvas>` (logo sederhana, nama, `N Selir | N Kekuatan`), digambar ulang hanya saat dibuka, layar berubah ukuran, tema berganti, atau datanya berubah. Ketuk kartu untuk mengubah nama (maks 16 huruf, disimpan di `S.name`). Kekuatan = jumlah serangan (`AT`) semua selir yang sudah bergabung; rumusnya ada di `pwr()` dalam `setting/layout.html`.
- **Edit Stat** (`setting/edit/`): ubah Food/Oil/Diamond/Gold/Iron (0 – 9.999.999), opsi *Unlock All Heroes* dan *Maximize All Heroes Level* (kedekatan Setia, level skill 12). **Terapkan** membuka konfirmasi; baru berjalan setelah **Ya, Terapkan**. Editor selalu mulai tertutup tiap masuk tab.
- **Import Stat** (`setting/import/`): pilih file `.json`, isinya dirapikan (selir tak dikenal dibuang, angka dibatasi), muncul ringkasan, lalu save sekarang ditimpa setelah dikonfirmasi.
- **Save Stat** (`setting/save/`): konfirmasi dulu, lalu mengunduh seluruh save sebagai `selir-apokalips_<nama>_<tanggal>.json` (format `{game, versi, disimpan, stat:{...}}`; isi mentah `selir_apo1` juga bisa di-import).
- **Reset Stat** (`setting/reset/`, tombol paling kiri, garis merah; Save Stat bergaris hijau): kembali ke save baru (persediaan, bangunan, selir awal), nama profil tetap. Ada konfirmasi; tidak bisa dibatalkan.

### Tambah menu Pengaturan
1. Salin `setting/_template/_template.html` menjadi `setting/<id>/<id>.html`, ganti `contoh` dengan `<id>`.
2. Tambahkan satu baris di `setting/manifest.html`: `{id:"<id>",name:"Nama Tombol"}` (opsional `cls:"cf-rs"` garis merah / `cf-sv` garis hijau).
3. Hanya `run()` yang wajib. Opsional: `on()` (tombol tampil aktif), `panel()` (HTML di bawah tombol), `close()` (dipanggil tiap tab dimasuki lagi). Contoh lengkapnya `setting/edit/edit.html`; daftar pembantu yang tersedia ada di komentar template.

## Skill BANTUAN & Efek Pembuka (Base Defend)
Skill GLOBAL (bukan milik selir): tombol bulat kanan-bawah atau tombol **Q**, cooldown `BNCD`=32 dtk. Pasukan 3 tank + 4 rider Harley memakai **gambar Markas persis** (`tankArt`, `bikeArt` dari `index.html`, dicetak lewat `dTank`/`dBike`). Efek yang sama (sorot lampu volumetrik, jejak rantai/ban di `DC`, kepulan asap knalpot, tembakan artileri Mach-disk + kawah ledakan `bnBoom`, rentetan shotgun/SCAR rider + selongsong kuningan) kini juga aktif penuh saat **pembuka permainan (intro)** ketika tank, rider, dan Bos keluar dari pintu blokade.

## Zombie & Visual Realistis (v35)
- **Tanpa Cut-in Banner Skill**: Banner cut-in tengah layar saat skill selir dihapus total beserta kodenya agar pandangan ke medan tempur tidak terhalang.
- **Visual Realistis Berbasis GPU/Canvas Cache**: Semua partikel asap, bola api ledakan, gelombang kejut (`PFX`), cahaya additif (`GLW`), sprite penembak taktis (`fg`), dan zombie (`ZSP`) dirender sekali ke tekstur kanvas offscreen untuk di-blit secara instan tanpa lag.
